// Package app contains the third-party app used to replace the default app in xray-core
package app
